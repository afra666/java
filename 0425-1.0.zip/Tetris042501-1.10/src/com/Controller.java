package com;

public class Controller {
	public	GameFrame gameFrame=new GameFrame();
	public	static GamePanel gamePanel=new GamePanel();
	public Controller() {
	
		gameFrame.add(gamePanel);
		//get focus
		gamePanel.requestFocus();
	}
	
	public void starGame() {
		
	}
}
