package com;

import javax.swing.JFrame;

import util.GlobalNum;

public class GameFrame extends JFrame implements GlobalNum{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public GameFrame() {
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setBounds(FRAME_X, FRAME_Y, FRAME_WIDTH, FRAME_HEIGHT);
		this.setLayout(null);
		this.setVisible(true);
		this.setResizable(false);
		
	}
}
