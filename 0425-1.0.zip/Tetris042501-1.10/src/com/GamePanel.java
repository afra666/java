package com;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JPanel;

import util.GlobalNum;

public class GamePanel extends JPanel  implements KeyListener,GlobalNum{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	Shape shape=new Shape();
	Ground ground=new Ground();
	int num2=0;
	int shapeRotateAr[][];
	int rdmDirectPlus=shape.RDM_DIRECT;
	Shape roteTmpNextShape=new Shape();
	Shape nextShape=new Shape();
	public GamePanel() {
		this.setBounds(PANEL_X0, PANEL_Y0, PANEL_WIDTH, PANEL_HEIGHT);

		//get focus
		this.addKeyListener(this);

		//多线程
		new Thread(new DelayDriver()).start();
	}

	//通过内部类来延时
	public class DelayDriver implements Runnable {
		public void run() {
			while (true) {

				
					try {
						Thread.sleep(DELAY_TIME_MS);

					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					
					if (ground.canGoDown(shape.u)) {
						shape.shapeNowY+=CELL;
						repaint();
					}
					else{
						ground.addShape(shape);
						System.out.println("Add shape");
						System.out.println("ground.uList.size()="+ground.uList.size());
						//完毕
						shape=null;
						shape=nextShape;
						nextShape=new Shape();
					}
				
			}
		}
	}

	@Override
	public void paint(Graphics g) {

		super.paint(g);
		nextShape.drawShape(g);
		//画shape
		shape.drawShape(g);
		ground.drawGround(g);
		this.drawBackground(g);
		
		g.drawString("SCORE", 280, 50);

	}

	public void drawBackground(Graphics g) {
		// 边框
		g.setColor(Color.cyan);
		g.drawRect(RECT_X, RECT_Y, RECT_WIDTH, RECT_HEIGHT);
	}

	@Override
	public void keyPressed(KeyEvent e) {
		int key=e.getKeyCode();
		if (key==KeyEvent.VK_LEFT) {
			if (ground.canGoLeft(shape.u)) {
				shape.shapeNowX-=CELL;
				repaint();
			}
		}
		if (key==KeyEvent.VK_RIGHT) {
			if (ground.canGoRight(shape.u)) {
				shape.shapeNowX+=CELL;
				repaint();
			}
		}
		if (key==KeyEvent.VK_DOWN) {
			if (ground.canGoDown(shape.u)) {
				shape.shapeNowY+=CELL;
				repaint();
			}
		}
		if (key==KeyEvent.VK_UP) {
			//错误写法:roteTmpNextShape=shape,与paint冲突;
			roteTmpNextShape.shapeNowX=shape.shapeNowX;
			roteTmpNextShape.shapeNowY=shape.shapeNowY;
			roteTmpNextShape.shapeAr2R=shape.shapeAr3R[(rdmDirectPlus+1)%4];

			//这句不能缺,与if对应
			roteTmpNextShape.shapeToUnit();
			if (ground.canRotate(roteTmpNextShape)) {
				shape.shapeAr2R=shape.shapeAr3R[(++rdmDirectPlus)%4];
				//repaint里面有shapeToUnit
				repaint();
			}
		}
	}

	@Override
	public void keyReleased(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}

	@Override
	public void keyTyped(KeyEvent arg0) {
		// TODO Auto-generated method stub

	}




}
