package com;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import util.GlobalNum;

public class Ground implements GlobalNum{
	public boolean canGoLeft=true;
	public boolean canGoRight=true;
	public boolean canGoDown=true;
	public boolean canRotate=true;
	List<Unit> uList=new ArrayList<Unit>();
	public int [][]groundAr= new int[22][10];
	public boolean over=false;
	
	
	public Ground() {

	}


	//左边界判断
	public boolean canGoLeft(List<Unit> u) {
		//first condition
		int cnt1=0;
		for (int i = 0; i < u.size(); i++) {
			if (u.get(i).getX0()/CELL>0) {cnt1++;}
		}
		//判断
		if (cnt1==4) {
			//second condition
			int cnt2=0;
			for (int big = 0; big < this.uList.size(); big++) {
				for (int lit = 0; lit < u.size(); lit++) {
					if ((uList.get(big).getX0()==u.get(lit).getX0()-CELL)&&(uList.get(big).getY0()==u.get(lit).getY0())) {
						cnt2++;
					}
				}
			}
			if (cnt2==0) {
				canGoLeft=true;
			}
			else {
				canGoLeft=false;
				
				System.out.println("Hit left");
			}
		}
		else {
			canGoLeft=false;
			
			System.out.println("Hit left");
		}
		
		return canGoLeft;
		

	}
	//右边界
	public boolean canGoRight(List<Unit> u) {
		//first condition
		int cnt=0;
		for (int i = 0; i < u.size(); i++) {
			if (u.get(i).getX0()/CELL<=groundAr[0].length-2) {cnt++;}
		}
		//判断
		if (cnt==4) {
			//second condition
			int cnt2=0;
			for (int big = 0; big < this.uList.size(); big++) {
				for (int lit = 0; lit < u.size(); lit++) {
					if ((uList.get(big).getX0()==u.get(lit).getX0()+CELL)&&(uList.get(big).getY0()==u.get(lit).getY0())) {
						cnt2++;
					}
				}
			}
			if (cnt2==0) {
				canGoRight=true;
			}
			else {
				canGoRight=false;
				
				System.out.println("Hit left");
			}
		}
		else {
			canGoRight=false;
			System.out.println("Hit right");
		}
		
		return canGoRight;
	}
	//向下判断
	public boolean canGoDown(List<Unit> u) {
		//first condition
		//second condition
		int cnt=0;
		for (int i = 0; i < u.size(); i++) {
			if (u.get(i).getY0()/CELL<=groundAr.length-2) {cnt++;}
		}
		//判断
		if (cnt==4) {
			//second condition
			int cnt2=0;
			//加空判断
			if (uList.size()!=0) {
				System.out.println(uList.size());
				for (int big = 0; big < this.uList.size(); big++) {
					for (int lit = 0; lit < u.size(); lit++) {
						//顶部判断
						if (uList.get(big).getY0()/CELL==2) {
							System.out.println("You lose");
							this.over=true;
						}
						if ((uList.get(big).getX0()==u.get(lit).getX0())&&(uList.get(big).getY0()==u.get(lit).getY0()+CELL)) {
							cnt2++;
						}
					}
				}
				
				if (cnt2==0) {
					canGoDown=true;
				}
				else {
					canGoDown=false;
					
					System.out.println("Hit down");
				}
			}
		}
		else {
			canGoDown=false;
			System.out.println("Hit down");
		}
		
		
		return canGoDown;
	}
	//旋转判断
	public boolean canRotate(Shape nextShape) {
		//first condition
		
		//以下正常
		int cnt1=0;
		for (int i = 0; i < nextShape.u.size(); i++) {
			if ((nextShape.u.get(i).getX0()/CELL>=0)
					&&(nextShape.u.get(i).getX0()/CELL<=9)
					&&(nextShape.u.get(i).getY0()/CELL<=21)
					) {
				cnt1++;
			}
		}
		if (cnt1==4) {
			//second condition
			int cnt2=0;
			canRotate=true;
			for (int big = 0; big < uList.size(); big++) {
				for (int lit = 0; lit < nextShape.u.size(); lit++) {
					//如果不相等
					if ((uList.get(big).getX0()==nextShape.u.get(lit).getX0())&&(uList.get(big).getY0()==nextShape.u.get(lit).getY0())) {
						cnt2++;
					}
					else {
						
					}
				}
			}
			
			if (cnt2==4) {
				canRotate=false;
			}
			else {
				canRotate=true;
			}
		}
		//针对cnt1的判断
		else {
			canRotate=false;
		}
		
		return canRotate;
	}
	//add
	public void addShape(Shape shape) {
		for (int i = 0; i < shape.u.size(); i++) {
			uList.add(shape.u.get(i));
		}
		//满行判断,逐行遍历
		int cnt=0;
		for (int groundLines = 0; groundLines <22; groundLines++) {
			for (int allU = 0; allU < uList.size(); allU++) {
				//第零行
				if (uList.get(allU).getY0()/CELL==groundLines) {
					cnt++;
					if (cnt==10) {
						removeGroundLine(groundLines);
//						userScore();
						System.out.print("start clear");
					}
				}
			}
			//遍历完一行后,计数器清零
			cnt=0;
		}
		
	}
	//第21行
	private void removeGroundLine(int groundLines) {
		//应该用iterator
		Iterator iter1=uList.iterator();
		while (iter1.hasNext()) {
			Unit tmpU=(Unit)iter1.next();
			if (tmpU.getY0()/CELL==groundLines) {
				iter1.remove();
			}
		}
		
		//这个用iter会出错
		for (int i = 0; i < uList.size(); i++) {
			if (uList.get(i).getY0()/CELL<groundLines) {
				uList.get(i).setY0(uList.get(i).getY0()+CELL);
			}
		}

		
	}


	//满行判断
	/**
	 * 1.当一个shape停止时,判断4个unit所在的行是否等于10cell,如果等于 ,删除
	 * @param g
	 */
	//画笔
	public void drawGround(Graphics g) {

		g.setColor(Color.BLACK);
		for (int i = 0; i < this.uList.size(); i++) {
			g.fill3DRect(this.uList.get(i).getX0()+LITTLE_BOUND,this.uList.get(i).getY0()+LITTLE_BOUND, CELL-LITTLE_BOUND2, CELL-LITTLE_BOUND2, true);
			//黑色画落地格子边框
			Graphics2D g2=(Graphics2D)g;
			g2.setStroke(new BasicStroke(2.0f));
			g2.drawRect(this.uList.get(i).getX0(),this.uList.get(i).getY0(), CELL, CELL);
		}
		

		//灰白色画地面全部格子,从第三行开始画
		g.setColor(Color.LIGHT_GRAY);
		for (int i = 2; i < groundAr.length; i++) {
			for (int j = 0; j < groundAr[0].length; j++) {
				g.draw3DRect(j*CELL, i*CELL, CELL, CELL,true);
			}
		}
	}

}

























