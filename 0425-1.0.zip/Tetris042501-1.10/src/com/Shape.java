package com;

import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import util.GlobalNum;

public class Shape implements GlobalNum{
	//产生形状
	Random random=new Random();
	final int RDM_TYPE=random.nextInt(7);
	final int RDM_DIRECT=random.nextInt(4);
	final int [][][]shapeAr3R=DATA[RDM_TYPE];
	//rdmDirect={0,1,2,3}
	int [][]shapeAr2R=shapeAr3R[RDM_DIRECT];
	
	public boolean canGoLeft=true;
	public boolean canGoRight=true;
	public boolean canGoDown=true;
	public boolean canRotate=true;
	//随机颜色
	

	int rdmColorNum=random.nextInt(7);
	Color color[]= {Color.YELLOW,Color.CYAN,Color.LIGHT_GRAY,Color.BLUE,Color.RED,Color.ORANGE,Color.GREEN};
	
	//初始化左上角坐标
	public int shapeNowX=X_SHAPE;
	public int shapeNowY=Y_SHAPE;

	public List<Unit> u=new ArrayList<Unit>();
	
	public Shape() {
		//不add会初始化异常
		u.add(new Unit());
		u.add(new Unit());
		u.add(new Unit());
		u.add(new Unit());
		
	}
	

			//shape to unit
		public void shapeToUnit() {

			//以下每次都需要调用
			//设置unit的坐标
			int cnt=0;
			for (int i = 0; i < shapeAr2R.length; i++) {
				for (int j = 0; j < shapeAr2R[0].length; j++) {
					if (shapeAr2R[i][j]==1) {
						//x坐标为setX0(shapeNowX+j*CELL);
						//y坐标为setY0(shapeNowY+i*CELL);

						u.get(cnt).setX0(shapeNowX+j*CELL);
						u.get(cnt).setY0(shapeNowY+i*CELL);
						cnt++;



					}
				}
			}
		}
		
	public void  drawShape(Graphics g) {
		g.setColor(color[rdmColorNum]);
		//每次,画shape
		shapeToUnit();
		for (int i = 0; i <u.size(); i++) {
			u.get(i).drawUnit(g);
		}
		//
		
	}
	
}
