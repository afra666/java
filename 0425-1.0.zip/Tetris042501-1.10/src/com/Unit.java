package com;

import java.awt.BasicStroke;
import java.awt.Graphics;
import java.awt.Graphics2D;

import util.GlobalNum;

public class Unit implements GlobalNum{
	int x0;
	int y0;
	
	
	public Unit() {

	}
	public void drawUnit(Graphics g) {
		//画实体格子边框
		
		g.fill3DRect(x0+LITTLE_BOUND, y0+LITTLE_BOUND, CELL-LITTLE_BOUND2, CELL-LITTLE_BOUND2, true);
		
		Graphics2D g2=(Graphics2D)g;
		g2.setStroke(new BasicStroke(2.0f));
		g2.drawRect(x0, y0, CELL, CELL);
		
		
		
	}
	
	
	
	public int getX0() {
		return x0;
	}
	public void setX0(int x0) {
		this.x0 = x0;
	}
	public int getY0() {
		return y0;
	}
	public void setY0(int y0) {
		this.y0 = y0;
	}

}