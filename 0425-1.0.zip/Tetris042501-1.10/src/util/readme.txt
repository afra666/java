1.shape{
x,y,speed,canRun,int shapeArAll[][][]=Ar.data;
int type=6
}

//图标美化